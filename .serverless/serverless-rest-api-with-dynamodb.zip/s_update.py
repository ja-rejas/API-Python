import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jarejas',
    application_name='todo-list-serverless',
    app_uid='ZV3pn6yvVcQ6339qwL',
    org_uid='0f23dcf5-eb6c-4d30-a71a-cccd80bfb672',
    deployment_uid='7eb7c3e7-229c-4e62-b4b4-c03299b144ae',
    service_name='serverless-rest-api-with-dynamodb',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.8.4',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'serverless-rest-api-with-dynamodb-dev-update', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/update.update')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
