import os
import json
import logging
import pprint

from todos import decimalencoder


import boto3
dynamodb = boto3.resource('dynamodb')
translate = boto3.client('translate')


def translateText(event, context):
    table = dynamodb.Table(os.environ['DYNAMODB_TABLE'])

    # fetch todo from the database
    result = table.get_item(
        Key={
            'id': event['pathParameters']['id'],
        }
    )
    aux = result['Item'].get("text")
    #result2 = translate.translate_text(Text="Texto de prueba", SourceLanguageCode='auto', TargetLanguageCode=event['pathParameters']['languages'])
    translatedValue = translate.translate_text(Text= aux, SourceLanguageCode='auto', TargetLanguageCode=event['pathParameters']['languages'])

    result2 = dict(text=translatedValue.get('TranslatedText'))
    result['Item'].update(result2)
    
    # create a response
    response = {
        "statusCode": 200,
        "body": json.dumps(result['Item'],
                           cls=decimalencoder.DecimalEncoder)
    }

    return response
